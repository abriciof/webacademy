export type ChangeLangDto = {
    lang: 'pt-BR' | 'en-US'
}