export enum TipoUsuarios {
    "ADMIN" = "f195c92f-9cba-4073-acb9-fe7287e1a9b2",
    "CLIENT" = "96bf68de-d5ca-4c9b-9832-6d60096d71e0"
}